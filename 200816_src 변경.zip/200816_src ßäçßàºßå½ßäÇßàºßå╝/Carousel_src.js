var currentImg = 1;
var activeClass = "active";
const firstDot = document.querySelector(".dot:nth-child(1)");
const lastDot = document.querySelector(".dot:nth-child(6)");

        function right_move() {
            var activeDot = document.querySelector(".active");
            currentImg++;
            if(currentImg === 7) {
                currentImg = 1;
            }
            img_slide.src = "/img/" + currentImg + ".png"
            if(activeDot) {
                var nextdot = activeDot.nextElementSibling;
                activeDot.classList.remove(activeClass);
                if(currentImg === 1) {
                    firstDot.classList.add(activeClass);
                } else {
                    nextdot.classList.add(activeClass);
                }
            }
        }

        function left_move() {
            var activeDot = document.querySelector(".active");
            currentImg--;
            if(currentImg === 0) {
                currentImg = 6;
            }
            img_slide.src = "/img/" + currentImg + ".png"
            if(activeDot) {
                var prevdot = activeDot.previousElementSibling;
                activeDot.classList.remove(activeClass);
                if(currentImg === 6) {
                    lastDot.classList.add(activeClass);
                } else {
                    prevdot.classList.add(activeClass);
                }
            }
        }
